export const config = {
  api_base_url: 'http://10.60.85.201/',
  appkey: 'K4PXZN3X1KNCbBdx'
}
